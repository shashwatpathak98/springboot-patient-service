export class Patient {
  id!: number;
  name!: string;
  visitedDoctor!: string;
  visitDate!: string;
  prescription!: string;
}
